(() => {
  "use strict";
  const H = window.HermitShell;
  const { $, $$, state, host } = H;
  const { say, busy, bind, open, close, confirmAction, selected } = H.ui;
  async function openDeploy(mode) {
    const app = state.selected;
    const value = await host.call("deploy.start", { appId: app.appId, mode }); state.deploy = value;
    const connection = value.mode === "lan" ? ["export HERMIT_ADDRESS='" + value.address + "'", "export HERMIT_SPKI_PIN='" + value.spkiPin + "'"] : ["adb forward tcp:8765 tcp:8765"];
    $("#deployConfig").textContent = [...connection, "Address: " + value.address, "App-Id: " + app.appId, "Authorization: Bearer " + value.token,
      value.spkiPin ? "TLS: 自签名证书 + SPKI 公钥固定" : "Transport: ADB-forwarded device loopback",
      "上传还需要 Idempotency-Key、X-Hermit-Expected-Release 与 X-Hermit-Content-SHA256。"].join("\n");
    open("#deployPanel");
  }
  bind("#developApp", () => openDeploy("adb")); bind("#developLanApp", () => openDeploy("lan"));
  const copy = async (text, label) => { await host.copy(text); say(label + "已复制。"); };
  let agentState = null, agentPoll = false;
  function renderAgent(value) {
    agentState = value;
    $("#agentStatus").textContent = value.active ? "已开启 · 所有应用可开发" : "未开启" + (value.reason ? " · " + value.reason : "");
    $(".developer-card").classList.toggle("active", !!value.active);
    $("#developmentDot").classList.toggle("hidden", !value.active);
    $("#agentToggle").classList.toggle("on", !!value.active);
    $("#agentToggle").setAttribute("aria-checked", String(!!value.active));
    $("#agentToggle").setAttribute("aria-label", value.active ? "关闭智能体开发模式" : "开启智能体开发模式");
    $("#copyAgentAddress").disabled = !value.active;
    const firstIp = (value.addresses || [])[0];
    const address = value.address || (firstIp ? "http://" + firstIp + ":8766" : "");
    $("#agentUrl").textContent = address || "未连接 Wi-Fi";
    $("#agentUrl").dataset.address = address;
    if (document.activeElement !== $("#agentPassword")) $("#agentPassword").value = value.password || "";
    $("#agentEvents").textContent = (value.events || []).slice().reverse().map(event => new Date(event.time).toLocaleTimeString() + "  " + event.tool + "  " + event.result).join("\n") || "暂无操作";
  }
  async function refreshAgent() {
    if (agentPoll) return;
    agentPoll = true;
    try { renderAgent(await host.call("agent.status")); } finally { agentPoll = false; }
  }
  bind("#agentToggle", async () => {
    if (agentState && agentState.active) {
      await host.call("agent.stop");
      renderAgent(await host.call("agent.status"));
      say("开发模式已关闭。");
      return;
    }
    const address = agentState && (agentState.addresses || [])[0];
    if (!address) throw new Error("请连接 Wi-Fi 后重试。");
    if (!await confirmAction("开启智能体开发模式？", "持有密码的电脑可管理全部应用。请仅在可信局域网使用。", "开启开发模式")) return;
    renderAgent(await host.call("agent.start", { address }));
    say("开发模式已开启，请仅向可信智能体分享连接信息。");
  });
  bind("#saveAgentPassword", async () => {
    const password = $("#agentPassword").value.trim();
    if (!/^[0-9]{6}$/.test(password)) throw new Error("密码必须是 6 位数字。");
    const value = await host.call("agent.resetPassword", { password });
    renderAgent(value);
    if (value.password !== password) throw new Error("当前 APK 版本暂不支持指定密码，请安装新版。");
    say("新密码已生效，旧密码已失效。");
  });
  $("#agentPassword").oninput = event => { event.currentTarget.value = event.currentTarget.value.replace(/\D/g, "").slice(0, 6); };
  bind("#copyAgentAddress", async () => {
    const address = $("#agentUrl").dataset.address;
    if (!address) throw new Error("请连接 Wi-Fi 后重试。");
    await copy(address, "局域网地址");
  });
  setInterval(async () => {
    if (document.hidden || !host.ready() || state.view !== "development") return;
    try { await refreshAgent(); } catch (_) {}
  }, 3000);
  bind("#copyDeploy", () => copy($("#deployConfig").textContent, "开发配置"));
  bind("#stopDeploy", async () => { await host.call("deploy.stop", {}); state.deploy = null; close("#deployPanel"); $("#deployConfig").textContent = ""; say("开发连接已停止。"); });
  H.features.development = { refreshAgent };
  H.copy = copy;
})();
