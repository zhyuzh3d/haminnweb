(() => {
  "use strict";
  const H = window.HermitShell;
  const methods = new Set(["apps.importZip", "backup.export", "support.open", "shell.reload","about.info", "about.openRepository", "agent.resetPassword", "agent.start", "agent.status", "agent.stop", "apps.archive", "apps.confirmDirectory", "apps.favorite", "apps.installOnline", "apps.launch", "apps.list", "apps.pickDirectory", "apps.pickIcon", "apps.pin", "apps.reinstall", "apps.releases", "apps.remove", "apps.rollback", "apps.scanQr", "apps.setCrossOriginNetwork", "apps.setNotificationEnabled", "apps.setRuntimeMode", "apps.update", "apps.updateFromSource", "apps.updateUrls", "backup.restore", "backup.restoreData", "deploy.start", "deploy.stop", "diagnostics.info", "licenses.info", "permissions.list", "permissions.revoke", "shell.updateLocal"]);
  async function call(method, params = {}) {
    if (!methods.has(method)) throw new Error("未登记的宿主操作：" + method);
    if (!window.hermit || !window.hermit.isReady) throw new Error("请在 HermitApp 中使用此功能。");
    try { return await window.hermit.call("host." + method, params); }
    catch (error) {
      if (error.code === "E_UNSUPPORTED") error.message = "当前 APK 不支持此功能，请更新 HermitApp。";
      throw error;
    }
  }
  H.host = { call, ready: () => !!(window.hermit && window.hermit.isReady),
    copy: text => {
      if (!window.hermit || !window.hermit.isReady) return Promise.reject(new Error("请在 HermitApp 中复制内容。"));
      return window.hermit.call("clipboard.write", { text, label: "Hermit" });
    } };
})();
