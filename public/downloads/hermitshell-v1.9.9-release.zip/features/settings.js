(() => {
  "use strict";
  const H = window.HermitShell;
  const { $, $$, state, host } = H;
  const { say, busy, bind, open, close, confirmAction, selected } = H.ui;
  const copy = (text, label) => H.copy(text, label);
  let theme = "system";
  try { theme = localStorage.getItem("hermit.theme") || "system"; } catch (_) {}
  function applyTheme(value) {
    theme = ["system", "light", "dark"].includes(value) ? value : "system";
    if (theme === "system") delete document.documentElement.dataset.theme;
    else document.documentElement.dataset.theme = theme;
    selected("#themeChoices", "themeChoice", theme);
    try { localStorage.setItem("hermit.theme", theme); } catch (_) {}
  }
  applyTheme(theme);
  $$("[data-theme-choice]").forEach(button => { button.onclick = () => applyTheme(button.dataset.themeChoice); });

  bind("#licensesButton", async () => { const value = await host.call("licenses.info", {}); $("#licensesOutput").textContent = value.text; open("#licensesPanel"); });
  bind("#diagnosticsButton", async () => { const report = await host.call("diagnostics.info", {}); $("#diagnosticsOutput").textContent = JSON.stringify(report, null, 2); open("#diagnosticsPanel"); });
  bind("#copyDiagnostics", () => copy($("#diagnosticsOutput").textContent, "诊断报告"));
  bind("#githubButton", () => host.call("about.openRepository", {}));

  bind("#updateLocalShell", async () => {
    const value = await host.call("shell.updateLocal", {});
    say("本地界面已更新到 " + value.localVersion + "，正在重新加载。");
  });
  window.hermitShellUnavailable = message => {
    say(message || "界面更新暂时不可用，继续使用当前本地界面。", true);
  };

  async function loadAbout() {
    const value = await host.call("about.info", {});
    $("#aboutVersion").textContent = value.version + "（" + value.versionCode + "）";
    $("#topApkVersion").textContent = value.version;
    $("#aboutAuthor").textContent = value.author;
    $("#aboutAppId").textContent = value.applicationId;
  }

  bind("#supportRepository", () => host.call("about.openRepository", {}));
  H.features.settings = { loadAbout };
})();
