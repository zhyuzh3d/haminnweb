(() => {
  "use strict";
  const H = window.HermitShell;
  const { $, $$, state, host } = H;
  const { say, busy, bind, open, close, confirmAction, selected } = H.ui;
  const sourceLabels = { "online-manifest": "线上安装包", "https-package": "线上安装包", github: "GitHub（海外可选）", zip: "本地 ZIP", import: "本地 ZIP", directory: "本地文件夹", agent: "本地创建", online: "线上网址" };
  function appSource(app) { return app.source || (["online", "online-manifest", "https-package", "github"].includes(app.sourceAdapter) ? "online" : "local"); }
  function appRuntime(app) { return app.runtimeMode || (app.liveUrl && !app.activeReleaseId ? "live" : "local"); }
  function hasLocal(app) { return typeof app.localAvailable === "boolean" ? app.localAvailable : !!app.activeReleaseId; }
  function hasLive(app) { return typeof app.liveAvailable === "boolean" ? app.liveAvailable : !!app.liveUrl; }
  function sourceLabel(app) { return sourceLabels[app.sourceAdapter] || (appSource(app) === "online" ? "线上 happ" : "本地 happ"); }
  function runtimeLabel(app) { return appRuntime(app) === "live" ? "线上实时运行" : "本地运行"; }
  function versionLabel(app) {
    for (const value of [app.activeVersion, app.downloadVersion]) {
      if (!value || typeof value !== "object") continue;
      if (typeof value.name === "string" && value.name.trim()) return value.name.trim().slice(0, 80);
      if (Number.isFinite(value.code)) return "版本 " + Math.trunc(value.code);
    }
    return "未标注版本";
  }
  function filterApps() {
    const candidates = state.view === "favorites" ? state.apps.filter(app => app.favorite) : state.apps;
    $$(".app-card").forEach(card => {
      const inCollection = state.view !== "favorites" || card.dataset.favorite === "true";
      card.classList.toggle("hidden", !inCollection);
    });
    $("#empty").classList.toggle("hidden", candidates.length !== 0);
    $("#collectionPrompt").textContent = state.view === "favorites"
      ? "已收藏【" + candidates.length + "】个HAPP应用"
      : "已安装【" + candidates.length + "】个HAPP应用";
    $("#emptyTitle").textContent = state.view === "favorites" ? "收藏你的第一个应用" : "添加你的第一个应用";
    $("#emptyMessage").textContent = state.view === "favorites" ? "点亮应用卡片上的爱心，常用工具就会集中在这里。" : "添加在线网址或导入原生 HTML、JavaScript 和 CSS 页面。";
  }
  function resetFilters() { filterApps(); }
  async function pin(app) {
    const value = await host.call("apps.pin", { appId: app.appId });
    say(value.requested ? "已请求添加到手机桌面，请确认系统提示。" : "当前桌面不支持固定图标。");
  }
  let refreshEpoch = 0;
  async function refresh() {
    const epoch = ++refreshEpoch;
    const result = await host.call("apps.list", {});
    if (epoch !== refreshEpoch) return;
    state.apps = result.apps || [];
    $("#libraryUnavailable").classList.add("hidden");
    $("#loading").classList.add("hidden");
    const root = $("#apps"), cards = document.createDocumentFragment();
    for (const app of state.apps) {
      const fragment = $("#appTemplate").content.cloneNode(true), card = fragment.querySelector(".app-card");
      card.dataset.appId = app.appId;
      card.dataset.search = [app.name, app.startUrl, app.liveUrl, app.sourceAdapter, sourceLabel(app), runtimeLabel(app)].join(" ").toLocaleLowerCase();
      card.dataset.source = appSource(app);
      card.dataset.favorite = String(!!app.favorite);
      fragment.querySelector(".app-name").textContent = app.name;
      fragment.querySelector(".app-source").textContent = runtimeLabel(app) + (appRuntime(app) === "live" ? " · " + app.startUrl : " · 本机代码");
      const color = ["blue", "violet", "orange", "green"][[...app.appId].reduce((n,c) => n + c.charCodeAt(0), 0) % 4];
      const appIcon = fragment.querySelector(".app-icon"), appIconMark = appIcon.querySelector("i");
      if (app.iconDataUrl) { appIcon.style.backgroundImage = "url(" + JSON.stringify(app.iconDataUrl).slice(1,-1) + ")"; appIcon.classList.add("custom"); appIconMark.classList.add("hidden"); }
      else { appIcon.classList.add(color); appIconMark.className = "fa-solid " + (appSource(app) === "local" ? "fa-cube" : "fa-globe"); }
      fragment.querySelector(".version-badge").textContent = versionLabel(app);
      fragment.querySelector(".launch").onclick = event => busy(event.currentTarget, () => host.call("apps.launch", { appId: app.appId }));
      const favorite = fragment.querySelector(".favorite"), favoriteIcon = favorite.querySelector("i");
      favorite.classList.toggle("active", !!app.favorite);
      favorite.setAttribute("aria-pressed", String(!!app.favorite));
      favorite.setAttribute("aria-label", app.favorite ? "取消收藏" : "收藏应用");
      favorite.title = app.favorite ? "取消收藏" : "收藏应用";
      favoriteIcon.className = (app.favorite ? "fa-solid" : "fa-regular") + " fa-heart";
      favorite.onclick = event => busy(event.currentTarget, async () => {
        const updated = await host.call("apps.favorite", { appId: app.appId, favorite: !app.favorite });
        app.favorite = !!updated.favorite;
        await refresh();
        say(app.favorite ? "已加入收藏。" : "已取消收藏。");
      });
      fragment.querySelector(".pin").onclick = event => busy(event.currentTarget, () => pin(app));
      fragment.querySelector(".manage").onclick = () => H.features.manage.openManage(app).catch(error => say(error.message, true));
      cards.append(fragment);
    }
    root.replaceChildren(cards);
    filterApps();
  }
  H.features.library = { refresh, filterApps, resetFilters, pin, appSource, appRuntime, hasLocal, hasLive, sourceLabel, runtimeLabel, versionLabel };
})();
