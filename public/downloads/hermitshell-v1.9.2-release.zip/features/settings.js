(() => {
  "use strict";
  const H = window.HermitShell;
  const { $, $$, state, host } = H;
  const { say, busy, bind, open, close, confirmAction, selected } = H.ui;
  const HERMIT_WEB_VERSION = H.version;
  const copy = (text, label) => H.copy(text, label);
  let theme = "system";
  try { theme = localStorage.getItem("hermit.theme") || "system"; } catch (_) {}
  function applyTheme(value) {
    theme = ["system", "light", "dark"].includes(value) ? value : "system";
    if (theme === "system") delete document.documentElement.dataset.theme;
    else document.documentElement.dataset.theme = theme;
    selected("#themeChoices", "themeChoice", theme);
    try { localStorage.setItem("hermit.theme", theme); } catch (_) {}
  }
  applyTheme(theme);
  $$("[data-theme-choice]").forEach(button => { button.onclick = () => applyTheme(button.dataset.themeChoice); });

  bind("#licensesButton", async () => { const value = await host.call("licenses.info", {}); $("#licensesOutput").textContent = value.text; open("#licensesPanel"); });
  bind("#diagnosticsButton", async () => { const report = await host.call("diagnostics.info", {}); $("#diagnosticsOutput").textContent = JSON.stringify(report, null, 2); open("#diagnosticsPanel"); });
  bind("#copyDiagnostics", () => copy($("#diagnosticsOutput").textContent, "诊断报告"));
  bind("#githubButton", () => host.call("about.openRepository", {}));

  let shellState = null;
  function renderShellState(value) {
    shellState = value;
    const online = value.configuredMode === "online";
    const currentVersion = HERMIT_WEB_VERSION;
    $("#brandDot").classList.toggle("online", value.runningMode === "online");
    $("#topWebVersion").textContent = currentVersion;
    $("#shellModeStatus").textContent = (value.runningMode === "online" ? "正在使用线上实时界面" : value.runningMode === "local-fallback" ? "线上不可用，已回退本地界面" : "正在使用本地界面") + " · 本地版本 " + value.localVersion;
    $("#useOnlineShell").disabled = online && value.runningMode === "online";
    $("#shellVersionSwitch").textContent = "当前界面版本：" + currentVersion;
    $("#useLocalShell").disabled = !online;
    $("#useLocalShell").classList.toggle("hidden", !online);
  }
  async function loadShellStatus() { renderShellState(await host.call("shell.status", {})); }
  bind("#useOnlineShell", async () => {
    if (!await confirmAction("使用线上实时界面？", "界面将从官网加载并随发布变化；无法连接时会回退本地版。", "切换到线上")) return;
    await host.call("shell.setMode", { mode: "online" });
  });
  bind("#useLocalShell", async () => {
    if (shellState && shellState.configuredMode === "local") return;
    await host.call("shell.setMode", { mode:"local" });
  });
  bind("#updateLocalShell", async () => {
    const value = await host.call("shell.updateLocal", {});
    renderShellState(value);
    say("本地界面已更新到 " + value.localVersion + (value.runningMode === "online" ? "，可切换到本地使用。" : "，正在重新加载。"));
  });
  window.hermitShellUnavailable = message => {
    say(message || "官网实时界面暂时不可用，当前使用本地版。", true);
    loadShellStatus().catch(() => {});
  };

  async function loadAbout() {
    const value = await host.call("about.info", {});
    $("#aboutVersion").textContent = value.version + "（" + value.versionCode + "）";
    $("#topApkVersion").textContent = value.version;
    $("#aboutAuthor").textContent = value.author;
    $("#aboutAppId").textContent = value.applicationId;
  }

  bind("#supportRepository", () => host.call("about.openRepository", {}));
  H.features.settings = { loadAbout, loadShellStatus };
})();
